"""From-scratch preprocessing utilities for the Bank Marketing assignment."""
import numpy as np
import pandas as pd
from math import sqrt

def manual_mean(values):
    values = list(values)
    return sum(values) / len(values)

def manual_median(values):
    values = sorted(values)
    n = len(values)
    return values[n // 2] if n % 2 else (values[n//2 - 1] + values[n//2]) / 2

def manual_mode(values):
    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    m = max(counts.values())
    return [k for k, v in counts.items() if v == m]

def manual_variance(values):
    mu = manual_mean(values)
    return sum((x - mu) ** 2 for x in values) / len(values)

def manual_std(values):
    return sqrt(manual_variance(values))

def manual_minmax(series, min_value=None, max_value=None):
    if min_value is None: min_value = series.min()
    if max_value is None: max_value = series.max()
    return (series - min_value) / (max_value - min_value)

def manual_standardize(series, mean_value=None, std_value=None):
    if mean_value is None: mean_value = series.mean()
    if std_value is None: std_value = series.std(ddof=0)
    return (series - mean_value) / std_value

def manual_label_encode(series, mapping=None):
    if mapping is None:
        mapping = {v: i for i, v in enumerate(sorted(series.dropna().unique()))}
    return series.map(mapping), mapping

def manual_one_hot_encode(series, categories=None, prefix=None):
    prefix = prefix or series.name
    categories = categories or sorted(series.dropna().unique())
    out = pd.DataFrame(index=series.index)
    for category in categories:
        out[f"{prefix}_{category}"] = (series == category).astype(int)
    return out, categories

def manual_iqr(series):
    q1 = series.quantile(.25)
    q3 = series.quantile(.75)
    iqr = q3 - q1
    return q1, q3, iqr, q1 - 1.5 * iqr, q3 + 1.5 * iqr

def manual_train_test_split(data, test_size=.20, seed=42):
    rng = np.random.default_rng(seed)
    idx = np.arange(len(data))
    rng.shuffle(idx)
    n_test = int(len(data) * test_size)
    return data.iloc[idx[n_test:]].copy(), data.iloc[idx[:n_test]].copy()
