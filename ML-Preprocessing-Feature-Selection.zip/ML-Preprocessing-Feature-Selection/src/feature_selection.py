"""From-scratch feature-selection utilities for the Bank Marketing assignment."""
import numpy as np
import pandas as pd
from math import log2

def manual_pearson(x, y):
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    xm, ym = x.mean(), y.mean()
    num = np.sum((x-xm)*(y-ym))
    den = np.sqrt(np.sum((x-xm)**2) * np.sum((y-ym)**2))
    return num / den if den else 0.0

def manual_variance(values):
    values = np.asarray(values, dtype=float)
    return np.mean((values - values.mean()) ** 2)

def manual_chi_square(feature, target):
    table = pd.crosstab(feature, target)
    observed = table.to_numpy(dtype=float)
    expected = observed.sum(axis=1, keepdims=True) @ observed.sum(axis=0, keepdims=True) / observed.sum()
    chi2 = np.sum((observed - expected)**2 / expected)
    dof = (observed.shape[0]-1) * (observed.shape[1]-1)
    return chi2, dof, table, expected

def manual_anova_two_groups(x, target):
    x, target = np.asarray(x, float), np.asarray(target)
    groups = [x[target == g] for g in np.unique(target)]
    overall = x.mean()
    ss_between = sum(len(g)*(g.mean()-overall)**2 for g in groups)
    ss_within = sum(np.sum((g-g.mean())**2) for g in groups)
    df_between = len(groups)-1
    df_within = len(x)-len(groups)
    return (ss_between/df_between)/(ss_within/df_within)

def manual_entropy(series):
    probs = pd.Series(series).value_counts(normalize=True)
    return -sum(p*log2(p) for p in probs if p > 0)

def manual_mutual_information(x, y):
    joint = pd.crosstab(x, y, normalize=True)
    px, py = joint.sum(axis=1), joint.sum(axis=0)
    mi = 0.0
    for xv in joint.index:
        for yv in joint.columns:
            pxy = joint.loc[xv, yv]
            if pxy > 0:
                mi += pxy * log2(pxy/(px[xv]*py[yv]))
    return mi
