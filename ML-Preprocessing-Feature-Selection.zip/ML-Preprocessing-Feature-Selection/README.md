# ML Preprocessing & Feature Selection — Bank Marketing

## Problem
Binary classification of whether a bank customer subscribed to a term deposit (`y`).

## Dataset
- Records: 45,211
- Columns: 17
- Input features: 16
- Numerical inputs: 7
- Categorical inputs: 9
- Target: `y`
- Literal missing values: 0
- Duplicate rows: 0

## Final Feature Selection
### Selected (10)
`duration`, `pdays`, `previous`, `campaign`, `balance`,
`poutcome`, `month`, `contact`, `housing`, `job`

### Removed (6)
`age`, `marital`, `education`, `default`, `loan`, `day`

The selection rule is documented in the notebook and is based on variance, Pearson correlation/ANOVA for numerical features, and Mutual Information/Chi-Square for categorical features.

## Techniques Implemented From Scratch
- Mean / median / mode / variance / standard deviation
- Missing-value analysis
- Duplicate and validity checks
- Label encoding
- One-hot encoding
- IQR outlier detection
- Z-score outlier detection
- Log transformation
- Min-Max normalization
- Standardization
- Manual train-test split
- Variance threshold
- Pearson correlation
- Chi-Square
- ANOVA F-Test
- Mutual Information

## Verification
After each important manual calculation, suitable Pandas/NumPy/SciPy/scikit-learn functionality is used only for verification or optional model validation.

## Team Members
| Student | Roll Number | Contribution |
|---|---|---|
| Student 1 | TODO | TODO |
| Student 2 | TODO | TODO |
| Student 3 | TODO | TODO |
| Student 4 | TODO | TODO |

## Dataset Source
TODO — add the original dataset source/link required by the assignment.

## Google Colab
TODO — paste Colab link here.

## Run
1. Keep `dataset/bank-full.csv` beside the notebook/project.
2. Open `notebooks/main_analysis.ipynb`.
3. Run all cells from top to bottom.

## Repository Structure
```text
ML-Preprocessing-Feature-Selection/
├── README.md
├── dataset/
│   └── bank-full.csv
├── notebooks/
│   └── main_analysis.ipynb
├── src/
│   ├── preprocessing.py
│   └── feature_selection.py
├── results/
│   ├── graphs/
│   └── outputs/
└── report/
```
